package edu.miu.Lab3.service.imp;

import edu.miu.Lab3.service.CommentService;

public class CommentServiceImp implements CommentService {
}
