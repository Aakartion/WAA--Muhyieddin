package edu.miu.Lab4.service.imp;


import edu.miu.Lab4.service.CommentService;

public class CommentServiceImp implements CommentService {
}
